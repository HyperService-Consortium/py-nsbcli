
HTTP_HEADERS = {'Content-Type': 'application/json'}

ENC = 'utf-8'
