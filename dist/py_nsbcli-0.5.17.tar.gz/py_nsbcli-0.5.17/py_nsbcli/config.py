import os.path as parsepath
HTTP_HEADERS = {'Content-Type': 'application/json'}

ENC = 'utf-8'
HOME_PATH = parsepath.dirname(__file__)
INCLUDE_PATH = parsepath.dirname(HOME_PATH) + "/include"
