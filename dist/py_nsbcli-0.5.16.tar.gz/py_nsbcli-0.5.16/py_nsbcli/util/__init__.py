
from .gojson import GoJson

